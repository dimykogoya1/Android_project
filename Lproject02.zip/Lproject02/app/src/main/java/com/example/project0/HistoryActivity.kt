import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.project0.R
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject


class ActivityHistoryActivity : AppCompatActivity() {

    private lateinit var requestQueue: RequestQueue
    private lateinit var recyclerView: RecyclerView
    private lateinit var activityHistoryAdapter: ActivityHistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activity_history)

        requestQueue = Volley.newRequestQueue(this)
        recyclerView = findViewById(R.id.recyclerViewActivityHistory)
        activityHistoryAdapter = ActivityHistoryAdapter(this)


        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = activityHistoryAdapter

        val userToken = "4455321!@"

        fetchActivityHistory(userToken)
    }

    private fun fetchActivityHistory(token: String) {
        val url = "https://jwuclasses.com/csis2023/exercise/getactivityhistory/"

        val jsonObject = JSONObject().apply {
            put("token", token)
        }

        val request = JsonObjectRequest(
            Request.Method.POST, url, jsonObject,
            Response.Listener { response ->
                handleSuccessfulResponse(response)
            },
            Response.ErrorListener { error: VolleyError? ->
                handleError(error)
            }
        )

        requestQueue.add(request)
    }

    private fun handleSuccessfulResponse(response: JSONObject) {
        try {
            if (response.has("success") && response.getBoolean("success")) {
                val activitiesArray = response.getJSONArray("activities")
                processActivityHistory(activitiesArray)
            } else {
                Log.e("Activity History", "Error: ${response.getString("error")}")
                showToast("Failed to fetch activity history")
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    private fun processActivityHistory(activitiesArray: JSONArray) {
        val activityList = mutableListOf<ActivityHistoryItem>()

        for (i in 0 until activitiesArray.length()) {
            val activityObject = activitiesArray.getJSONObject(i)

            val activityDate = activityObject.optString("activity_date", "")
            val activityName = activityObject.optString("activity_name", "")
            val hoursDuration = activityObject.optString("hours_duration", "")
            val calories = activityObject.optInt("calories", 0)
            val imageUrl = activityObject.optString("image", "")

            val activity = ActivityHistoryItem(activityDate, activityName, hoursDuration, calories, imageUrl)
            activityList.add(activity)
        }

        activityHistoryAdapter.setData(activityList)
    }

    data class ActivityHistoryItem(
        val activityDate: String,
        val activityName: String,
        val hoursDuration: String,
        val calories: Int,
        val imageUrl: String
    )

    private fun handleError(error: VolleyError?) {
        error?.printStackTrace()
        showToast("Failed to fetch activity history")
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    inner class ActivityHistoryAdapter(private val context: Context) :
        RecyclerView.Adapter<ActivityHistoryAdapter.ViewHolder>() {

        private val data = mutableListOf<ActivityHistoryItem>()

        fun setData(newData: List<ActivityHistoryItem>) {
            data.clear()
            data.addAll(newData)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_activity_history, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val currentItem = data[position]

            holder.textViewDate.text = currentItem.activityDate
            holder.textViewName.text = currentItem.activityName
        }

        override fun getItemCount(): Int {
            return data.size
        }

        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val textViewDate: TextView = itemView.findViewById(R.id.textViewDate)
            val textViewName: TextView = itemView.findViewById(R.id.textViewName)
        }
    }
}
