package com.example.project0

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject


class LogActivity : AppCompatActivity() {

    private lateinit var requestQueue: RequestQueue

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log)

        val activityTypeSpinner: Spinner = findViewById(R.id.spinnerActivityType)
        val durationEditText: EditText = findViewById(R.id.editTextDuration)
        val saveButton: Button = findViewById(R.id.buttonSave)
        val cancelButton: Button = findViewById(R.id.buttonCancel)
        val logTextView: TextView = findViewById(R.id.textViewLog)

        requestQueue = Volley.newRequestQueue(this)

        val activityTypes = arrayOf("Running", "Walking", "Swimming")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, activityTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        activityTypeSpinner.adapter = adapter

        saveButton.setOnClickListener {

            val selectedActivityType = activityTypeSpinner.selectedItem.toString()
            val enteredDuration = durationEditText.text.toString()


            if (enteredDuration.isNotEmpty()) {

                val logMessage = "Activity: $selectedActivityType, Duration: $enteredDuration minutes"
                logTextView.text = logMessage


                saveActivity(selectedActivityType, enteredDuration)
            } else {

                durationEditText.error = "Please enter the duration"
            }
        }

        cancelButton.setOnClickListener {

            finish()
        }
    }

    private fun saveActivity(activityType: String, duration: String) {

        val activityData = JSONObject().apply {
            put("activityType", activityType)
            put("duration", duration.toInt())

        }

        val saveActivityUrl = "https://jwuclasses.com/csis2023/exercise/[lowercase_name]."
        val request = JsonObjectRequest(
            Request.Method.POST, saveActivityUrl, activityData,
            { _ ->

            },
            { _: VolleyError? ->

            }
        )

        request.setShouldCache(false)

        requestQueue.add(request)
    }

    override fun onDestroy() {
        super.onDestroy()
        requestQueue.cancelAll(this)
    }
}
