package com.example.project0;

import android.app.Activity;

public class MainActivity2 extends Activity {
}
