package com.example.project0

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException
import org.json.JSONObject

class MainMenuActivity : AppCompatActivity() {

    private lateinit var requestQueue: RequestQueue

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        requestQueue = Volley.newRequestQueue(this)

        val logoutButton: Button = findViewById(R.id.buttonLogout)
        val logActivityButton: Button = findViewById(R.id.buttonLogActivity)
        val activityHistoryButton: Button = findViewById(R.id.buttonActivityHistory)
        val totalCaloriesTextView: TextView = findViewById(R.id.textViewTotalCalories)


        val loggedInUser = "John Doe"
        supportActionBar?.title = "Welcome, $loggedInUser"


        fetchTotalCalories()

        logoutButton.setOnClickListener {

            finish()
        }

        logActivityButton.setOnClickListener {
            val intent = Intent(this, LogActivity::class.java)
            startActivity(intent)
        }

        activityHistoryButton.setOnClickListener {
            val intent = Intent(this, ActivityHistoryActivity::class.java)
            startActivity(intent)
        }
    }

    private fun fetchTotalCalories() {
        val url = "https://jwuclasses.com/csis2023/exercise/[lowercase_name]"
        val token = "dimy@gmail.com"

        val jsonObject = JSONObject().apply {
            put("token", token)
        }

        val request = JsonObjectRequest(
            Request.Method.POST, url, jsonObject,
            Response.Listener { response ->

                try {
                    val success = response.getBoolean("success")

                    if (success) {
                        val totalCalories = response.getInt("total_calories")
                        updateTotalCalories(totalCalories)
                    } else {

                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            },
            Response.ErrorListener { error: VolleyError? ->
                error?.printStackTrace()
            }
        )

        requestQueue.add(request)
    }

    private fun updateTotalCalories(totalCalories: Int) {
        val totalCaloriesTextView: TextView = findViewById(R.id.textViewTotalCalories)
        totalCaloriesTextView.text = "Total Calories: $totalCalories"
    }
}
