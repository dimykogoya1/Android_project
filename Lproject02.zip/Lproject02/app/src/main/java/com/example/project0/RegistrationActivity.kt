package com.example.project0

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class RegistrationActivity : AppCompatActivity() {

    private lateinit var requestQueue: RequestQueue

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        requestQueue = Volley.newRequestQueue(this)

        val signUpButton: Button = findViewById(R.id.buttonSignUp)
        signUpButton.setOnClickListener {
            val emailEditText: EditText = findViewById(R.id.editTextEmail)
            val passwordEditText: EditText = findViewById(R.id.editTextPassword)

            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                val jsonObject = JSONObject().apply {
                    put("email", email)
                    put("password", password)
                    put("firstname", "John")
                    put("lastname", "Doe")
                }

                Log.v("Registration Sent JSON", jsonObject.toString())

                val registrationUrl = "https://jwuclasses.com/csis2023/exercise/[lowercase_name]."
                val request = JsonObjectRequest(
                    Request.Method.POST, registrationUrl, jsonObject,
                    { response ->
                        Log.v("Registration Received JSON", response.toString())
                        Toast.makeText(
                            this@RegistrationActivity,
                            "Registration successful!",
                            Toast.LENGTH_SHORT
                        ).show()

                        val intent = Intent(this@RegistrationActivity, LoginActivity::class.java)
                        startActivity(intent)
                        finish()
                    },
                    { error: VolleyError? ->
                        handleRegistrationError(error)
                    }
                )

                request.setShouldCache(false)
                requestQueue.add(request)
            } else {
                // Display a message if email or password is empty
                Toast.makeText(
                    this@RegistrationActivity,
                    "Please enter email and password",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun handleRegistrationError(error: VolleyError?) {
        if (error?.networkResponse != null) {
            val errorMessage = String(error.networkResponse.data)
            Log.e("Registration Network Error", "Error: $errorMessage")

            if (errorMessage.contains("user_already_exists")) {
                Toast.makeText(
                    this@RegistrationActivity,
                    "Registration failed: User with this email already exists.",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    this@RegistrationActivity,
                    "Registration failed: $errorMessage",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            Log.e("Registration Network Error", "Error: ${error?.toString()}")
            Toast.makeText(
                this@RegistrationActivity,
                "Registration failed. Please try again.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        requestQueue.cancelAll(this)
    }
}
