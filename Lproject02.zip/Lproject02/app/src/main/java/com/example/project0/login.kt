package com.example.project0

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Response
import retrofit2.Call
import retrofit2.Callback

class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var createAccountButton: Button
    private lateinit var progressBar: ProgressBar

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        emailEditText = findViewById(R.id.editTextEmail)
        passwordEditText = findViewById(R.id.editTextPassword)
        loginButton = findViewById(R.id.buttonLogin)
        createAccountButton = findViewById(R.id.buttonCreateAccount)
        progressBar = findViewById(R.id.progressBar)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()


            if (email.isNotEmpty() && password.isNotEmpty()) {
                // Authenticate user with coroutines
                authenticateUser(email, password)
            } else {
                showToast("Please enter email and password")
            }
        }

        createAccountButton.setOnClickListener {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
        }
    }

    private fun authenticateUser(email: String, password: String) {
        // Show loading indicator
        showLoading(true)

        val authService = RetrofitClient.authService

        val call: Unit = authService.login(email, password)
        
        call.enqueue(object : Callback<AuthTokenResponse> {
            override fun onResponse(
                call: Call<AuthTokenResponse>,
                response: retrofit2.Response<AuthTokenResponse>
            ) {

                showLoading(false)

                if (response.isSuccessful) {
                    val authToken = response.body()?.token

                    startMainMenuActivity()
                    finish() // Close the LoginActivity
                } else {
                    showToast("Login failed. Please check your credentials.")
                }
            }

            override fun onFailure(call: Call<AuthTokenResponse>, t: Throwable) {
                // Hide loading indicator
                showLoading(false)

                showToast("Network error. Please try again.")
            }
        })
    }

    class RetrofitClient {
        companion object {
            val authService: Any
                get() {
                    TODO()
                }
        }

    }

    private fun showLoading(isLoading: Boolean) {
        progressBar.visibility = if (isLoading) ProgressBar.VISIBLE else ProgressBar.GONE
    }

    private fun startMainMenuActivity() {
        val intent = Intent(this@LoginActivity, MainMenuActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(this@LoginActivity, message, Toast.LENGTH_SHORT).show()
    }
}

private fun Any.enqueue(callback: Callback<AuthTokenResponse>) {

}

private fun Any.login(email: String, password: String) {

}

class AuthTokenResponse {

    val token: Any = TODO()
}